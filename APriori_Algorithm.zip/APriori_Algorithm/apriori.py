# -*- coding: utf-8 -*-
"""
Created on Mon May 17 22:15:12 2021

@author: TCFATAS
"""

#apriori algoritması kullanılarak birliktelik kuralı uygulama işlemi yapılacaktır.
#hazır kütüphaneler yerine yazılmış bir kodu kütüphane gibi kullanmayı öğreneceğiz.

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#veri kümesini yükleme
#kullanılan datada header olmadığı için None yazıldı
veriler = pd.read_csv('sepet.csv', header = None)

# excelde yer alan tüm satırları bir listenin elemanı haline getirmek gerekiyor.

t = []
for i in range (0,7501):
    t.append([str(veriler.values[i,j]) for j in range (0,20)])

#apriori algoritması 
    
from apyori import apriori
kurallar = apriori(t,min_support=0.01,min_confidence=0.2,min_lift=3,min_length=2)

print(list(kurallar))