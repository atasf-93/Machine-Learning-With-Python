# -*- coding: utf-8 -*-
"""
Created on Tue May 18 23:01:39 2021

@author: TCFATAS
"""


import numpy as np
import pandas as pd

yorumlar = pd.read_csv('Restaurant_Reviews.csv',sep='\t')

import re #regular expression kütüphanesini ekleme 
import nltk

from nltk.stem.porter import PorterStemmer #kelimeleri köklerine indireceğiz.ekleri ayırmayı hedefliyoruz.
ps = PorterStemmer()

nltk.download('stopwords')#durma kelimelerini indirir. ingilizce kelimeler
from nltk.corpus import stopwords
#stop word-->anlam belirtmeyen kelimelerdir.(duygu belirtmeyen)
#Preprocessing (Önişleme)
derlem = []
for i in range(1000):
    yorum = re.sub('[^a-zA-Z]',' ',yorumlar['Review'][i])#imla işaretlerini silme işlemi yapar.
    yorum = yorum.lower()#yazının tamamını küçük harfe çevirir.
    yorum = yorum.split()#tüm kelimeleri bir listenin elemanı haline gitirme
    #kelimeleri kök ve eklerini birbirinden ayırmak için kullanılır.
    yorum = [ps.stem(kelime) for kelime in yorum if not kelime in set(stopwords.words('english'))]
    #kelimelerin arasına boşluk koyarak cümle oluşturma
    yorum = ' '.join(yorum)
    #oluşturulan tüm cümleler derlem içine koyulmaktadır.
    derlem.append(yorum)
    
#Feautre Extraction ( Öznitelik Çıkarımı)
#Bag of Words (BOW)
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(max_features = 2000)#metinde geçen kelimelerim sayısılması ve sayının bir matrşxe kaydedilmesi
X = cv.fit_transform(derlem).toarray() # bağımsız değişken
y = yorumlar.iloc[:,1].values # bağımlı değişken
 
#makine öğrenmesi algoritması
from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.20, random_state = 0)

from sklearn.naive_bayes import GaussianNB
gnb = GaussianNB()
gnb.fit(X_train,y_train)

y_pred = gnb.predict(X_test)

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test,y_pred)
print(cm)

