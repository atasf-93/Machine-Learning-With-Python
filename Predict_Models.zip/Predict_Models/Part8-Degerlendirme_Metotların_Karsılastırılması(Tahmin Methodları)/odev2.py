# -*- coding: utf-8 -*-
"""
Created on Mon Mar  8 00:18:40 2021

@author: TCFATAS
"""

#odev icerigi asagıdaki gibidir
#gerekli-gereksiz bagımsız degıskenleri bulunuz.
#5 farklı yönteme göre resresyon modellerini cıkarınız
#Yöntemlerin basarılarını karsılastırınız
#10 yıl tecrubeli ve 100 puan alnıs bir ceo ve aynı ozelliklere
#sahip bir müdürün 5 yöntemler de tahmin edip sonucları yorumlayınız.

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.metrics import r2_score
import statsmodels.api as sm
#veri yukleme
veriler=pd.read_csv('maaslar_yeni.csv')

#x değerine bağlı olarak çalıştırmak için değişiklik yapıldı.
x=veriler.iloc[:,2:3]
y=veriler.iloc[:,5:]
X=x.values
Y=y.values

#corrolation matrix değerinin verilmesi için kullanılır.
#datada yer alan değişkenlerin (bağımsız değişkenler) birbirleri
#ile ilişkisini ifade etmektedir.
print(veriler.corr())

#linear regression
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X,Y)

#lineer regression için rapor çıktısı
model = sm.OLS(lin_reg.predict(X),X)
print(model.fit().summary())

print('Linear R2 degeri')
print(r2_score(Y,lin_reg.predict(X)))


#polynomial regression
from sklearn.preprocessing import PolynomialFeatures
poly_reg=PolynomialFeatures(degree  = 2)
x_ploy = poly_reg.fit_transform(X)
print(x_ploy)

lin_reg2=LinearRegression()
lin_reg2.fit(x_ploy,y)

from sklearn.preprocessing import PolynomialFeatures
poly_reg=PolynomialFeatures(degree  = 4)
x_ploy = poly_reg.fit_transform(X)
print(x_ploy)

lin_reg2=LinearRegression()
lin_reg2.fit(x_ploy,y)

print(lin_reg.predict([[11]]))
print(lin_reg.predict([[6.6]]))


print(lin_reg2.predict(poly_reg.fit_transform([[6.6]])))
print(lin_reg2.predict(poly_reg.fit_transform([[11]])))

#linear reg2 modelinin OLS sonuçları
print('poly ols')
model2=sm.OLS(lin_reg2.predict(poly_reg.fit_transform(X)),X)
print(model2.fit().summary())

print('Polynomial R2 degeri')
print(r2_score(Y,lin_reg2.predict(poly_reg.fit_transform(X))))

#support vektor uygulaması kısmı asagıdaki gibidir
from sklearn.preprocessing import StandardScaler

sc1=StandardScaler()

x_olcekli = sc1.fit_transform(X)

sc2=StandardScaler()
y_olcekli = np.ravel(sc2.fit_transform(Y.reshape(-1,1)))


from sklearn.svm import SVR

svr_reg = SVR(kernel='rbf')
svr_reg.fit(x_olcekli,y_olcekli)

print(svr_reg.predict([[11]]))
print(svr_reg.predict([[6.6]]))

#svr modelinin OLS sonuçları
print('svr ols')
model3=sm.OLS(svr_reg.predict(x_olcekli),x_olcekli)
print(model2.fit().summary())

print('SVR R2 degeri')
print(r2_score(y_olcekli,svr_reg.predict(x_olcekli)))  
#karar agacları için ölçeklendirme yapmaya gerek yoktur.
#karar agacları için kullanılan kod bloğu aşağıdaki gibidir:
    
from sklearn.tree import DecisionTreeRegressor
r_dt=DecisionTreeRegressor(random_state=0)
r_dt.fit(X,Y)
Z = X + 0.5
K = X - 0.5

#farklı bir grafik çizimine geçmek için plt.show() kullanılır.
plt.show()
print(r_dt.predict([[11]]))
print(r_dt.predict([[6.6]]))

#decision tree modelinin OLS sonuçları
print('dt ols')
model4=sm.OLS(r_dt.predict(X),X)
print(model4.fit().summary())

print('Decision Tree R2 degeri')
print(r2_score(Y,r_dt.predict(X)))
#Random Agac Kullanarak Tahminleme
#n_estimators ile kaç adet agac cizilecegi belirtilir.
from sklearn.ensemble import RandomForestRegressor

rf_reg=RandomForestRegressor(n_estimators=10,random_state=0)
rf_reg.fit(X,Y.ravel())

print(rf_reg.predict([[6.6]]))

#random forest modelinin OLS sonuçları
print('rf ols')
model5=sm.OLS(rf_reg.predict(X),X)
print(model5.fit().summary())

#R2 Yöntremi
print('Random Forest R2 degeri')
print(r2_score(Y,rf_reg.predict(X)))
print(r2_score(Y,rf_reg.predict(K)))
print(r2_score(Y,rf_reg.predict(Z)))


#Özet R2 degerleri
print('-----------------------------------------')
print('Linear R2 degeri')
print(r2_score(Y,lin_reg.predict(X)))

print('Polynomial R2 degeri')
print(r2_score(Y,lin_reg2.predict(poly_reg.fit_transform(X))))

print('SVR R2 degeri')
print(r2_score(y_olcekli,svr_reg.predict(x_olcekli)))  

print('Decision Tree R2 degeri')
print(r2_score(Y,r_dt.predict(X)))

print('Random Forest R2 degeri')
print(r2_score(Y,rf_reg.predict(X)))
