# -*- coding: utf-8 -*-
"""
Created on Wed Mar  3 00:13:07 2021

@author: TCFATAS
"""

#1.kutuphaneler
import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd

#2.veri onisleme
#2.1 veri yukleme
veriler=pd.read_csv('satislar.csv')
print(veriler)

aylar=veriler[['Aylar']]
print(aylar)

satislar=veriler[['Satislar']]
print(satislar)


#2.6 verilerin egitim ve test icin bolunmesi
from sklearn.model_selection import train_test_split

x_train, x_test,y_train,y_test=train_test_split(aylar,satislar,test_size=0.33,random_state=0)

#2.7 verilerin olceklenmesi
from sklearn.preprocessing import StandardScaler

'''
sc=StandardScaler()

X_train = sc.fit_transform(x_train)
X_test = sc.fit_transform(x_test)
Y_train = sc.fit_transform(y_train)
Y_test = sc.fit_transform(y_test)

#model inşası (linear regression)(standardize edilmiş hali ile tahminleme)
from sklearn.linear_model import LinearRegression
lr=LinearRegression()
lr.fit(X_train,Y_train)

#modelin uygulanması
tahmin=lr.predict(X_test)
'''
#gerçek degerler üzerinden tahminleme
from sklearn.linear_model import LinearRegression
lr=LinearRegression()
lr.fit(x_train,y_train)

#modelin uygulanması
tahmin=lr.predict(x_test)

#modelin gorsellestirme bolumu
#cizme islemi yapmadan önce verinin sıralanması gerekir
x_train=x_train.sort_index()
y_train=y_train.sort_index()
plt.plot(x_train,y_train)
plt.plot(x_test,lr.predict(x_test))

#grafiğe baslık vermek icin kullanılır
plt.title('aylara göre satış')
plt.xlabel('Aylar')
plt.ylabel('Satışlar')












