# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 11:45:14 2021

@author: TCFATAS
"""

import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd

#class tanımı
#class yapısına ait fonksiyon tanımlaması
#self kendisine verilen parametreye ek bir parametre alabilmesi
class insan:
    boy = 180
    def kosmak(self,b):
        return b + 10
    
ali = insan()
print(ali.boy)
print(ali.kosmak(90))

#liste tanımı
l = [1,3,4]  #liste tanımı
print(l)
