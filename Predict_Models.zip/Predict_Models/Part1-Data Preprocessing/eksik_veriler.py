# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 12:40:15 2021

@author: TCFATAS
"""

import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd

#veri yukleme 
veriler=pd.read_csv('eksikveriler.csv')
print(veriler)

#eksik veriler
#sayısal verilerde eksik verinin olması durumunda ilgili 
#kolon için ortalama alınır ve eksik deger verine ortamala deger yazılır.
#ortalama alıp eksik veri yerine yazmayı aşağıdaki gibi yaparız.

#sci kit learn kullanılır.
#eksik verilerin tamamlanması için kullanılan yapı asagıdaki gibidir.

from sklearn.impute import SimpleImputer

imputer = SimpleImputer(missing_values=np.nan,strategy='mean')
#tüm satırların gelmesi için : koyduk ve 1 den 4 e kadar kolanlar gelecek.

Yas =veriler.iloc[:,1:4].values
print(Yas)

#fit öğrenilecek degeri bulmak için kullanılır. Bu fonksiyonu egitmek
#icin kullanıyoruz.fit ile ogrenip transfor ile de ogrendigini uyguluatacagız.


imputer = imputer.fit(Yas[:,1:4])
Yas[:,1:4] = imputer.transform(Yas[:,1:4])
print(Yas)
