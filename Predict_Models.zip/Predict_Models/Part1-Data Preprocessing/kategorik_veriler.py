# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 12:59:16 2021

@author: TCFATAS
"""

import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd

veriler=pd.read_csv('eksikveriler.csv')
print(veriler)

#kategorik bir nominal degeri sayısal olarak nasış ifade ederiz islemini
#asagıdaki kod blokları ile yapmalıyız. 
#Bu yapı icin encoding islemi kullanacagız.

ulke = veriler.iloc[:,0:1].values
print(ulke)

from sklearn import preprocessing
le = preprocessing.LabelEncoder()

ulke[:,0]=le.fit_transform(veriler.iloc[:,0])

print(ulke)
#fit ve transform islemini aynı anda yapmak için OneJot Encoder yapısı kullanıldı.
ohe = preprocessing.OneHotEncoder()
#toarray-->numpy array olarak sonucu almamızı saglar
ulke=ohe.fit_transform(ulke).toarray()
print(ulke)