# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 10:51:32 2021

@author: TCFATAS
"""
#import=kutuphanelerin yuklenmesi için kullanılan bir komuttur.
#pd diyerek kutuphaneyi kısaltıp ilgili fonksiyonlara ulasıyoruz.

#ders 6 : kutuphanelerin yuklenmesi
#kutuphaneler bolumu
import pandas as pd #verileri duzgun bir sekilde tutmak ve ulasmak icin kullanılır.
import numpy as np #buyuk sayi ve hesaplama islemleri için kullanılır
import matplotlib.pyplot as plt#cizimler icin kullanılır.

#kod bolumu