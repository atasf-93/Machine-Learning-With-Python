# -*- coding: utf-8 -*-
"""
Created on Sun Feb 28 11:26:08 2021

@author: TCFATAS
"""
#kutuphaneler
import numpy as np 
import matplotlib.pyplot as plt
import pandas as pd

#kodlar
#veri yukleme
#excel dosyası olduğu için read_csv kullanılır.
#tek tırnak veya cift tırnak kullanılabilir.
#dosyanın calistıgı dizin ile veriler aynı yerde olmalı
#absolute dizin verilirse dosyanın bulundugu yeri de icerir.
veriler=pd.read_csv('veriler.csv')
#pd.read_csv("veriler.csv")
print(veriler)
#veri on isleme
boy=veriler[['boy']]

print(boy)

boykilo=veriler[['boy','kilo']]
print(boykilo)