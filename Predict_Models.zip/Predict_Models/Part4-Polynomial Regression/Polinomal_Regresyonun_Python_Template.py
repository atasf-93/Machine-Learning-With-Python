# -*- coding: utf-8 -*-
"""
Created on Sat Mar  6 19:07:04 2021

@author: TCFATAS
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#veri yukleme
veriler=pd.read_csv('maaslar.csv')


#data frame dilimleme (slice)
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:]

#numpy array dönüşümü
X=x.values
Y=y.values

#dogrusal model olusturma
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X,Y)



#dogrusal olmayan model olusturma
#2.dereceden polinom
from sklearn.preprocessing import PolynomialFeatures
poly_reg=PolynomialFeatures(degree  = 2)
x_ploy = poly_reg.fit_transform(X)
lin_reg2=LinearRegression()
lin_reg2.fit(x_ploy,y)

#4. dereceden polinom
poly_reg3=PolynomialFeatures(degree  = 4)
x_ploy = poly_reg3.fit_transform(X)
print(x_ploy)
lin_reg3=LinearRegression()
lin_reg3.fit(x_ploy,y)

#gorsellestirme 
plt.scatter(X,Y,color='red')
plt.plot(x, lin_reg.predict(X),color='blue')
plt.show()

plt.scatter(X,Y,color='red')
plt.plot(X,lin_reg2.predict(poly_reg.fit_transform(X)),color='blue')
plt.show()

plt.scatter(X,Y,color='red')
plt.plot(X,lin_reg3.predict(poly_reg3.fit_transform(X)),color='blue')
plt.show()


#tahminler
#lineer model ile tahminleme
print(lin_reg.predict([[11]]))
print(lin_reg.predict([[6.6]]))

#polinom model ile tahminleme
print(lin_reg2.predict(poly_reg.fit_transform([[6.6]])))
print(lin_reg2.predict(poly_reg.fit_transform([[11]])))

