# -*- coding: utf-8 -*-
"""
Created on Sat Mar  6 13:48:01 2021

@author: TCFATAS
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

#veri yukleme
veriler=pd.read_csv('maaslar.csv')

#veriyi iki parcaya bolme islemi
#eğitim seviyesi ve maas kolon olarak aldık.
x=veriler.iloc[:,1:2]
y=veriler.iloc[:,2:]
X=x.values
Y=y.values

#lineer regresyon uygulasak nasıl olur diye kontrol ediyoruz
from sklearn.linear_model import LinearRegression
lin_reg = LinearRegression()
lin_reg.fit(X,Y)

plt.scatter(X,Y,color='red')
plt.plot(x, lin_reg.predict(X),color='blue')
plt.show()

#ploynomial regression(ikinci dereceden olması durumunda)
#ilk asamada elimizdeki veriye polinomal özellik kazandıracagız.
#sonrasında lineer regresyon uygulayacagız
from sklearn.preprocessing import PolynomialFeatures
poly_reg=PolynomialFeatures(degree  = 2)
x_ploy = poly_reg.fit_transform(X)
print(x_ploy)

lin_reg2=LinearRegression()
lin_reg2.fit(x_ploy,y)
plt.scatter(X,Y,color='red')
plt.plot(X,lin_reg2.predict(poly_reg.fit_transform(X)),color='blue')
plt.show()

#ploynomial regression(dördüncü dereceden olması durumunda)
#ilk asamada elimizdeki veriye polinomal özellik kazandıracagız.
#sonrasında lineer regresyon uygulayacagız
from sklearn.preprocessing import PolynomialFeatures
poly_reg=PolynomialFeatures(degree  = 4)
x_ploy = poly_reg.fit_transform(X)
print(x_ploy)

lin_reg2=LinearRegression()
lin_reg2.fit(x_ploy,y)
plt.scatter(X,Y,color='red')
plt.plot(X,lin_reg2.predict(poly_reg.fit_transform(X)),color='blue')
plt.show()

#tahminler
#lineer model ile tahminleme
print(lin_reg.predict([[11]]))
print(lin_reg.predict([[6.6]]))

#polinom model ile tahminleme
print(lin_reg2.predict(poly_reg.fit_transform([[6.6]])))
print(lin_reg2.predict(poly_reg.fit_transform([[11]])))

